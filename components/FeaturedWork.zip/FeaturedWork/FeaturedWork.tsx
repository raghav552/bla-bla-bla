import styles from "./FeaturedWork.module.css";
import { projects } from "./data";
import Project from "./Project";

export default function FeaturedWork() {
  return (
 <section className={styles.section}>
  <div className={styles.header}>
    <span className={styles.eyebrow}>
      SELECTED WORK
    </span>

    <h2 className={styles.heading}>
      Proof that strategy
      <br />
      becomes growth.
    </h2>

    <p className={styles.description}>
      Every project is built to solve a business problem,
      strengthen a brand, and generate measurable growth.
    </p>
  </div>

  {projects.map((project) => (
    <Project key={project.id} project={project} />
  ))}
</section>
  );
}