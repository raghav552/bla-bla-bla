export const projects = [
  {
    id: 1,
    category: "Website Development",
    title: "Luxury Real Estate Platform",
    challenge:
      "Outdated website with poor conversions and weak brand perception.",
    solution:
      "Designed and developed a premium, conversion-focused digital experience.",
    outcome: "+186% Qualified Leads",
    image: "/images/project-1.jpg",
  },
  {
    id: 2,
    category: "Motion Graphics",
    title: "High-Impact Social Campaign",
    challenge:
      "Low engagement and inconsistent visual identity across platforms.",
    solution:
      "Created cinematic motion graphics and social-first creative assets.",
    outcome: "4.2M Organic Reach",
    image: "/images/project-2.jpg",
  },
  {
    id: 3,
    category: "Brand Identity",
    title: "Modern Brand Transformation",
    challenge:
      "Brand lacked trust and premium positioning.",
    solution:
      "Built a complete visual identity system with modern brand assets.",
    outcome: "Stronger Brand Recall",
    image: "/images/project-3.jpg",
  },
];