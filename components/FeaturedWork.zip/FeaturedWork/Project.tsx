import styles from "./FeaturedWork.module.css";

type ProjectProps = {
  project: {
    id: number;
    category: string;
    title: string;
    challenge: string;
    solution: string;
    outcome: string;
    image: string;
  };
};

export default function Project({ project }: ProjectProps) {
  return (
    <article className={styles.project}>
      <div className={styles.content}>
        <span className={styles.category}>{project.category}</span>

        <h2 className={styles.title}>{project.title}</h2>

        {/* Browser Mockup */}
        <div className={styles.imagePlaceholder}>
          <div className={styles.browserContent}>
            <div className={styles.browserHero}></div>

            <div className={styles.browserLine}></div>
            <div className={styles.browserLineShort}></div>

            <div className={styles.browserGrid}>
              <div className={styles.browserCard}></div>
              <div className={styles.browserCard}></div>
              <div className={styles.browserCard}></div>
            </div>
          </div>
        </div>

        <div className={styles.details}>
          <div>
            <h4>Challenge</h4>
            <p>{project.challenge}</p>
          </div>

          <div>
            <h4>Solution</h4>
            <p>{project.solution}</p>
          </div>

          <div>
            <h4>Outcome</h4>
            <p>{project.outcome}</p>
          </div>
        </div>

        <button className={styles.button}>
          View Case Study
        </button>
      </div>
    </article>
  );
}