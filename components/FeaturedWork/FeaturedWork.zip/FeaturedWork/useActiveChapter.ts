"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Tracks which of `count` registered elements currently sits in the
 * viewport's center band, so a chapter rail can highlight the active one.
 * Consumers register each element with the ref returned by `registerRef(i)`.
 */
export function useActiveChapter(count: number) {
  const nodes = useRef<(HTMLElement | null)[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (!entry.isIntersecting) return;
          const index = nodes.current.findIndex((el) => el === entry.target);
          if (index !== -1) setActiveIndex(index);
        });
      },
      { threshold: 0, rootMargin: "-45% 0px -45% 0px" }
    );

    nodes.current.forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, [count]);

  const registerRef = (index: number) => (el: HTMLElement | null) => {
    nodes.current[index] = el;
  };

  return { activeIndex, registerRef };
}
